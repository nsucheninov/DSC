Configuration RunScript
{
	Param (
		[string]$NodeName = "localhost"
	)
	
    Import-DscResource �ModuleName PSDesiredStateConfiguration

	Node $NodeName
	{
		File Test1
		{
			Ensure = "Present"
			Type = "Directory"
			DestinationPath = "C:\Test1"
		}
		
	}
}