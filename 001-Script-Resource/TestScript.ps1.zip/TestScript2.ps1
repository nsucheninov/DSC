Configuration RunScript
{
	Param (
		[string]$NodeName = "localhost"
	)
	
    Import-DscResource �ModuleName "PSDesiredStateConfiguration"

	Node $NodeName
	{
		Script DownloadFile
		{
			
			TestScript = { $false }
			SetScript ={
				$source = "https://github.com/nsucheninov/DSC/raw/master/001-Script-Resource/TestScript.ps1.zip"
				$filename1 = $source.Substring($source.LastIndexOf("/") + 1)
				$dest = "C:\WindowsAzure\TestScript.ps1.zip"
				Invoke-WebRequest $source -OutFile $dest
				Expand-Archive $dest -DestinationPath "C:\TestDSC" -Force
			}
			GetScript = {@{Result = "bla bla 3"}}
			
		}
	}
}