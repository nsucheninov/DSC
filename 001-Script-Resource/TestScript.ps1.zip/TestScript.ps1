Configuration RunScript
{
	Param (
		[string]$NodeName = "localhost"
	)
	
    Import-DscResource �ModuleName "PSDesiredStateConfiguration"

	Node $NodeName
	{
		File NewFolder
		{
			Ensure = "Present"
			Type = "Directory"
			DestinationPath = "C:\TestDSC"
		}
		
		Script DownloadFile
		{
			
			TestScript = {
				Test-Path "C:\TestDSC\test.log"
			}
			SetScript ={
				$source = "https://github.com/nsucheninov/DSC/raw/master/001-Script-Resource/TestScript.ps1.zip"
				$dest = "C:\TestDSC\package.zip"
				Invoke-WebRequest $source -OutFile $dest
			}
			GetScript = {@{Result = "bla bla"}}
			
			DependsOn = "[File]NewFolder"
		}
	}
}