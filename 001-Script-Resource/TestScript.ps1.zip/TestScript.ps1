Configuration RunScript
{
	Param (
		[string]$NodeName = "localhost"
	)
	
    Import-DscResource �ModuleName "PSDesiredStateConfiguration"

	Node $NodeName
	{
		Script DownloadFile
		{
			
			TestScript = {
				Write-Verbose "bla bla"
				return $false
			}
			SetScript ={
				$source = "https://github.com/nsucheninov/DSC/raw/master/001-Script-Resource/TestScript.ps1.zip"
				$filename = $source.Substring($source.LastIndexOf("/") + 1)
				$dest = "C:\WindowsAzure\" + $filename
				Write-Verbose $source
				Write-Verbose $filename
				Write-Verbose $dest
				Invoke-WebRequest $source -OutFile $dest
				Expand-Archive $dest -DestinationPath "C:\TestDSC" -Force
#				Remove-Item $dest
			}
			GetScript = {@{Result = "bla bla"}}
			
		}
	}
}