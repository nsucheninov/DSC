Configuration RunScript
{
	Param (
		[Parameter(Mandatory=$True)]
		[string]$source
	)
	
    Import-DscResource �ModuleName "PSDesiredStateConfiguration"

	Node localhost
	{
		Script DownloadFile
		{
			
			TestScript = { $false }
			SetScript ={
				Write-Verbose "Start logging"
				Write-Verbose "source = $source"
				$filename = [System.IO.Path]::GetFileName($source)
				$dest = "C:\WindowsAzure\" + $filename
				Invoke-WebRequest $source -OutFile $dest
				Expand-Archive $dest -DestinationPath "C:\DSCTest1" -Force
				Remove-Item $dest
			}
			GetScript = {@{Result = ""}}
			
		}
	}
}