Configuration RunScript
{
	Param (
		[string]$source
	)
	
    Import-DscResource �ModuleName "PSDesiredStateConfiguration"

	Node localhost
	{
		Script DownloadFile
		{
			
			TestScript = { $false }
			SetScript ={
				$filename = $source.Substring($source.LastIndexOf("/") + 1)
				$dest = "C:\WindowsAzure\" + $filename
				Invoke-WebRequest $source -OutFile $dest
				Expand-Archive $dest -DestinationPath "C:\DSCTest1" -Force
				Remove-Item $dest
			}
			GetScript = {@{Result = ""}}
			
		}
	}
}