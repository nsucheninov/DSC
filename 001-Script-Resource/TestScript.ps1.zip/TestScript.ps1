Configuration RunScript
{
	Param (
		$sourceUrl,
		$destinationPath
	)
	
    Import-DscResource �ModuleName "PSDesiredStateConfiguration"

	Node localhost
	{
		Script DownloadFile
		{
			
			TestScript = { $false }
			GetScript = {@{Result = ""}}
			SetScript ={
				$tmpDest = "C:\WindowsAzure\" + [System.IO.Path]::GetFileName($using:sourceUrl)
				Write-Verbose "tmpDest = $tmpDest"
				Invoke-WebRequest $using:sourceUrl -OutFile $tmpDest
				Expand-Archive $tmpDest -DestinationPath $using:destinationPath -Force
				Remove-Item $tmpDest
			}
		}
	}
}