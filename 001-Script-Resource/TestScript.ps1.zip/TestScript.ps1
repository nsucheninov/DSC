Configuration RunScript
{
	Param (
		[string]$NodeName = "localhost",
		[string]$packageUrl
	)
	
    Import-DscResource �ModuleName "PSDesiredStateConfiguration"

	Node $NodeName
	{
		File NewFolder
		{
			Ensure = "Present"
			Type = "Directory"
			DestinationPath = "C:\TestDSC"
		}
		
		Script DownloadFile
		{
			
			TestScript = {
				$fileName = [System.IO.Path]::GetFileName($packageUrl)
				$fileName >> C:\TestDSC\test.log
				Test-Path "C:\TestDSC\$fileName"
			}
			SetScript ={
				$source = $packageUrl
				$source >> C:\TestDSC\test.log
				$fileName = [System.IO.Path]::GetFileName($packageUrl)
				$fileName >> C:\TestDSC\test.log
				$dest = "C:\TestDSC\$fileName"
				Invoke-WebRequest $source -OutFile $dest
			}
			GetScript = {@{Result = "bla bla"}}
			
			DependsOn = "[File]NewFolder"
		}
	}
}