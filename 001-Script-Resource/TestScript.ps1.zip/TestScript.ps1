Configuration RunScript
{
	Param (
		$sourceUrl
	)
	
    Import-DscResource �ModuleName "PSDesiredStateConfiguration"

	Node localhost
	{
		Script DownloadFile
		{
			
			TestScript = { $false }
			SetScript ={
				Write-Verbose "Start logging"
				Write-Verbose "sourceUrl = $using:sourceUrl"
				$filename = [System.IO.Path]::GetFileName($using:sourceUrl)
				$dest = "C:\WindowsAzure\" + $filename
				Write-Verbose "filename = $filename"
				Write-Verbose "dest = $dest"
				Invoke-WebRequest $using:sourceUrl -OutFile $dest
				Expand-Archive $dest -DestinationPath "C:\DSCTest1" -Force
				Remove-Item $dest
			}
			GetScript = {@{Result = ""}}
			
		}
	}
}