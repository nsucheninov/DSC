Configuration RunScript
{
	Param (
		$sourceUrl,
		$destinationPath
	)
	
    Import-DscResource �ModuleName "PSDesiredStateConfiguration"

	Node localhost
	{
		Script DownloadFile
		{
			
			TestScript = { $false }
			SetScript ={
				#$filename = [System.IO.Path]::GetFileName($using:sourceUrl)
				$tmpDest = "C:\WindowsAzure\" + [System.IO.Path]::GetRandomFileName()
				Write-Verbose "dest = $dest"
				Invoke-WebRequest $using:sourceUrl -OutFile $tmpDest
				Expand-Archive $tmpDest -DestinationPath $using:destinationPath -Force
				Remove-Item $tmpDest
			}
			GetScript = {@{Result = ""}}
			
		}
	}
}