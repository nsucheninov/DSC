Configuration RunScript
{
	Param (
		$NodeName = 'localhost'
	)
	
    Import-DscResource �ModuleName "PSDesiredStateConfiguration"

	Node $NodeName
	{
		File NewFolder
		{
			Ensure = "Present"
			Type = "Directory"
			DestinationPath = "C:\TestDSC"
		}
		
		Script DownloadFile
		{
			
			TestScript = {
				Test-Path "C:\TestDSC\WebDeploy_amd64_en-US.msi"
			}
			SetScript ={
				$source = "https://download.microsoft.com/download/0/1/D/01DC28EA-638C-4A22-A57B-4CEF97755C6C/WebDeploy_amd64_en-US.msi"
				$dest = "C:\TestDSC\WebDeploy_amd64_en-US.msi"
				Invoke-WebRequest $source -OutFile $dest
			}
			GetScript = {@{Result = "DownloadWebDeploy"}}
			
			DependsOn = "[File]NewFolder"
		}
	}
}