Configuration RunScript
{
	Param (
		$NodeName = 'localhost'
	)
	
	Node $NodeName
	{
		File NewFolder
		{
			Ensure = "Present"
			Type = "Directory"
			DestinationPath = "C:\TestDSC"
		}
		
		Script DownloadFile
		{
			
			TestScript = { Test-Path 'C:\TestDSC' }
			
			SetScript = {
				$sw = New-Object System.IO.StreamWriter("C:\TestDSC\TestFile.txt")
				$sw.WriteLine("Some sample string")
				$sw.Close()
			}

			GetScript = {
				@{ Result = "bla bla" } 
			}

			
			DependsOn = "[File]NewFolder"
		}
	}
}