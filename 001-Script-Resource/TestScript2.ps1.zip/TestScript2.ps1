Configuration RunScript
{
	Param (
		[string]$NodeName = "localhost"
	)
	
    Import-DscResource �ModuleName PSDesiredStateConfiguration

	Node $NodeName
	{
		Script Test1
		{
			TestScript { $false }
			GetScript { @{Result = "bla"} }
			StartScript 
			{
				New-Item -path "C:\Test2" -Type directory
			}
		}
	}
}