Configuration RunScript
{

	Node localhost
	{
		Script Test1
		{
			TestScript = { $false }
			GetScript = { @{Result = "bla"} }
			SetScript = {
				New-Item "C:\\Test1" -type directory
			}
		}
	}
}