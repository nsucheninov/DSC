Configuration RunScript
{

	Node localhost
	{

		Log BeforeTest1 {
			Message = "Start running the file resource with ID Test1"
		}

		File Test1 {
			Ensure = "Present"
			Type = "Directory"
			DestinationPath = "C:\Test1"
			DependsOn = "[Log]BeforeTest1"

		}
		
		Log AfterTest1 {
			Message = "Finished running the file resource with ID Test1"
			DependsOn = "[File]Test1"
		}
	}
}