Configuration RunScript
{
	Param (
		[string]$NodeName = "localhost"
	)
	
    Import-DscResource �ModuleName PSDesiredStateConfiguration

	Node $NodeName
	{
		Script Test1
		{
			TestScript { $false }
			GetScript { @{Result = "bla"} }
			StartScript 
			{
				$dest = "C:\Test2"
				New-Item $dest -Type directory
			}
		}
	}
}