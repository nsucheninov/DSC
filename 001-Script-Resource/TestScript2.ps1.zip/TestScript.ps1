Configuration RunScript
{
	Param (
		[string]$packageUrl
	)
	
    Import-DscResource �ModuleName "PSDesiredStateConfiguration"

	Node localhost
	{
		Script DownloadFile
		{
			
			TestScript = { $false }
			SetScript ={
				$filename = $packageUrl.Substring($packageUrl.LastIndexOf("/") + 1)
				$dest = "C:\WindowsAzure\" + $filename
				Invoke-WebRequest $packageUrl -OutFile $dest
				Expand-Archive $dest -DestinationPath "C:\DSCTest1" -Force
				Remove-Item $dest
			}
			GetScript = {@{Result = ""}}
			
		}
	}
}